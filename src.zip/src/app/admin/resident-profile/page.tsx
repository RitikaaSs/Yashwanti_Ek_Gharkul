import { Suspense } from "react";
import ResidentProfile from "./ResidentProfile";

export default function ResidentProfilePage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <ResidentProfile />
    </Suspense>
  );
}
